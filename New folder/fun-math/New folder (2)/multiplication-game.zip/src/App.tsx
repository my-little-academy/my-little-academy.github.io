import React, { useState } from 'react';
import './App.css';
import GameHeader from './components/GameHeader';
import DifficultySelector from './components/DifficultySelector';
import MultiplicationGame from './components/MultiplicationGame';
import ScoreBoard from './components/ScoreBoard';
import Instructions from './components/Instructions';

export interface GameStats {
  totalQuestions: number;
  correctAnswers: number;
  currentStreak: number;
  highestStreak: number;
  totalScore: number;
}

export interface DifficultyLevel {
  id: string;
  name: string;
  description: string;
  minDigits: number;
  maxDigits: number;
  scoreMultiplier: number;
}

function App() {
  const [currentView, setCurrentView] = useState<'menu' | 'instructions' | 'game'>('menu');
  const [selectedDifficulty, setSelectedDifficulty] = useState<DifficultyLevel | null>(null);
  const [gameStats, setGameStats] = useState<GameStats>({
    totalQuestions: 0,
    correctAnswers: 0,
    currentStreak: 0,
    highestStreak: 0,
    totalScore: 0
  });

  const difficulties: DifficultyLevel[] = [
    {
      id: 'easy',
      name: 'مبتدئ',
      description: 'رقم واحد × رقم واحد',
      minDigits: 1,
      maxDigits: 1,
      scoreMultiplier: 1
    },
    {
      id: 'medium',
      name: 'متوسط',
      description: 'رقمان × رقم واحد',
      minDigits: 2,
      maxDigits: 1,
      scoreMultiplier: 2
    },
    {
      id: 'hard',
      name: 'صعب',
      description: 'رقمان × رقمان',
      minDigits: 2,
      maxDigits: 2,
      scoreMultiplier: 3
    },
    {
      id: 'expert',
      name: 'خبير',
      description: 'ثلاثة أرقام × رقمان',
      minDigits: 3,
      maxDigits: 2,
      scoreMultiplier: 4
    }
  ];

  const handleStartGame = (difficulty: DifficultyLevel) => {
    setSelectedDifficulty(difficulty);
    setCurrentView('game');
  };

  const handleBackToMenu = () => {
    setCurrentView('menu');
    setSelectedDifficulty(null);
  };

  const updateGameStats = (newStats: Partial<GameStats>) => {
    setGameStats(prev => ({ ...prev, ...newStats }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-500 to-pink-500">
      <div className="container mx-auto px-4 py-6">
        <GameHeader />
        
        {currentView === 'menu' && (
          <div className="mt-8 space-y-8">
            <ScoreBoard stats={gameStats} />
            
            <div className="bg-white rounded-3xl shadow-2xl p-8 mx-auto max-w-4xl">
              <div className="text-center mb-8">
                <img 
                  src="/images/math-kids.jpg" 
                  alt="أطفال يتعلمون الرياضيات" 
                  className="w-48 h-32 object-cover rounded-2xl mx-auto mb-6"
                />
                <h2 className="text-3xl font-bold text-gray-800 mb-4">اختر مستوى الصعوبة</h2>
                <p className="text-gray-600 text-lg">ابدأ رحلتك في تعلم الضرب العمودي!</p>
              </div>
              
              <DifficultySelector 
                difficulties={difficulties}
                onSelectDifficulty={handleStartGame}
              />
              
              <div className="text-center mt-8">
                <button
                  onClick={() => setCurrentView('instructions')}
                  className="bg-green-500 hover:bg-green-600 text-white px-8 py-3 rounded-xl text-lg font-semibold transition-colors duration-300 shadow-lg"
                >
                  📚 كيفية اللعب
                </button>
              </div>
            </div>
          </div>
        )}

        {currentView === 'instructions' && (
          <Instructions onBack={() => setCurrentView('menu')} />
        )}

        {currentView === 'game' && selectedDifficulty && (
          <MultiplicationGame
            difficulty={selectedDifficulty}
            onBackToMenu={handleBackToMenu}
            gameStats={gameStats}
            updateGameStats={updateGameStats}
          />
        )}
      </div>
    </div>
  );
}

export default App;