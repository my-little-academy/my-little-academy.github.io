import React from 'react';
import { DifficultyLevel } from '../App';

interface DifficultySelectorProps {
  difficulties: DifficultyLevel[];
  onSelectDifficulty: (difficulty: DifficultyLevel) => void;
}

const DifficultySelector: React.FC<DifficultySelectorProps> = ({ 
  difficulties, 
  onSelectDifficulty 
}) => {
  const getDifficultyColor = (difficultyId: string) => {
    switch (difficultyId) {
      case 'easy': return 'from-green-400 to-green-600';
      case 'medium': return 'from-blue-400 to-blue-600';
      case 'hard': return 'from-orange-400 to-orange-600';
      case 'expert': return 'from-red-400 to-red-600';
      default: return 'from-gray-400 to-gray-600';
    }
  };

  const getDifficultyIcon = (difficultyId: string) => {
    switch (difficultyId) {
      case 'easy': return '🌱';
      case 'medium': return '⭐';
      case 'hard': return '🔥';
      case 'expert': return '💎';
      default: return '🎯';
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {difficulties.map((difficulty) => (
        <button
          key={difficulty.id}
          onClick={() => onSelectDifficulty(difficulty)}
          className={`bg-gradient-to-br ${getDifficultyColor(difficulty.id)} hover:scale-105 transform transition-all duration-300 text-white p-6 rounded-2xl shadow-lg hover:shadow-xl`}
        >
          <div className="text-center">
            <div className="text-4xl mb-3">
              {getDifficultyIcon(difficulty.id)}
            </div>
            <h3 className="text-2xl font-bold mb-2">{difficulty.name}</h3>
            <p className="text-lg opacity-90 mb-4">{difficulty.description}</p>
            <div className="bg-white bg-opacity-20 rounded-lg p-3">
              <div className="text-sm font-medium">
                مضاعف النقاط: ×{difficulty.scoreMultiplier}
              </div>
            </div>
          </div>
        </button>
      ))}
    </div>
  );
};

export default DifficultySelector;