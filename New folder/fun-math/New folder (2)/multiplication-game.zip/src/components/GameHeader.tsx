import React from 'react';

const GameHeader: React.FC = () => {
  return (
    <div className="text-center bg-white rounded-3xl shadow-2xl p-8 mb-8 mx-auto max-w-4xl">
      <div className="flex items-center justify-center gap-4 mb-4">
        <img 
          src="/images/math-symbols.jpg" 
          alt="رموز الرياضيات" 
          className="w-16 h-16 object-cover rounded-full"
        />
        <h1 className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600">
          🎮 لعبة الضرب العمودي
        </h1>
        <img 
          src="/images/calculator.jpg" 
          alt="آلة حاسبة" 
          className="w-16 h-16 object-cover rounded-full"
        />
      </div>
      
      <p className="text-xl text-gray-700 font-semibold">
        تعلم الضرب بطريقة ممتعة وتفاعلية! 🌟
      </p>
      
      <div className="mt-4 flex justify-center items-center gap-4">
        <span className="bg-yellow-100 text-yellow-800 px-4 py-2 rounded-full text-sm font-medium">
          🏆 تعلم خطوة بخطوة
        </span>
        <span className="bg-green-100 text-green-800 px-4 py-2 rounded-full text-sm font-medium">
          ⭐ احصل على النقاط
        </span>
        <span className="bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-sm font-medium">
          🎯 تحدي نفسك
        </span>
      </div>
    </div>
  );
};

export default GameHeader;