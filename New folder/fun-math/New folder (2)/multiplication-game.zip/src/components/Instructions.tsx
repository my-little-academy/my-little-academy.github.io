import React from 'react';

interface InstructionsProps {
  onBack: () => void;
}

const Instructions: React.FC<InstructionsProps> = ({ onBack }) => {
  return (
    <div className="bg-white rounded-3xl shadow-2xl p-8 mx-auto max-w-4xl">
      <div className="text-center mb-8">
        <img 
          src="/images/graduation.jpg" 
          alt="تعليم" 
          className="w-24 h-24 object-cover rounded-full mx-auto mb-4"
        />
        <h2 className="text-3xl font-bold text-gray-800 mb-4">📚 كيفية اللعب</h2>
      </div>

      <div className="space-y-6">
        <div className="bg-blue-50 border-r-4 border-blue-500 p-6 rounded-lg">
          <h3 className="text-xl font-bold text-blue-800 mb-3 flex items-center">
            <span className="text-2xl mr-3">🎯</span>
            الهدف من اللعبة
          </h3>
          <p className="text-blue-700 text-lg">
            تعلم طريقة الضرب العمودي (التقليدي) من خلال حل المسائل خطوة بخطوة والحصول على النقاط.
          </p>
        </div>

        <div className="bg-green-50 border-r-4 border-green-500 p-6 rounded-lg">
          <h3 className="text-xl font-bold text-green-800 mb-3 flex items-center">
            <span className="text-2xl mr-3">📝</span>
            خطوات الحل
          </h3>
          <ol className="text-green-700 text-lg space-y-2 list-decimal list-inside">
            <li>اختر مستوى الصعوبة المناسب لك</li>
            <li>ادخل إجابة كل خطوة في المربع المناسب</li>
            <li>ابدأ من خانة الآحاد ثم انتقل للعشرات</li>
            <li>لا تنس إضافة الناتج المنقول من الخطوة السابقة</li>
            <li>احسب المجموع النهائي</li>
          </ol>
        </div>

        <div className="bg-purple-50 border-r-4 border-purple-500 p-6 rounded-lg">
          <h3 className="text-xl font-bold text-purple-800 mb-3 flex items-center">
            <span className="text-2xl mr-3">⭐</span>
            نظام النقاط
          </h3>
          <div className="text-purple-700 text-lg space-y-2">
            <p>• إجابة صحيحة: +10 نقاط × مضاعف المستوى</p>
            <p>• سلسلة نجاحات: نقاط إضافية</p>
            <p>• إكمال المستوى: مكافأة خاصة</p>
          </div>
        </div>

        <div className="bg-yellow-50 border-r-4 border-yellow-500 p-6 rounded-lg">
          <h3 className="text-xl font-bold text-yellow-800 mb-3 flex items-center">
            <span className="text-2xl mr-3">💡</span>
            نصائح مهمة
          </h3>
          <ul className="text-yellow-700 text-lg space-y-2 list-disc list-inside">
            <li>خذ وقتك في حل كل خطوة</li>
            <li>راجع حسابك قبل الإرسال</li>
            <li>استخدم المساعدة عند الحاجة</li>
            <li>تدرب على المستويات السهلة أولاً</li>
          </ul>
        </div>

        <div className="bg-gradient-to-br from-pink-100 to-purple-100 p-6 rounded-lg">
          <h3 className="text-xl font-bold text-gray-800 mb-3 flex items-center">
            <span className="text-2xl mr-3">🏆</span>
            مثال على الضرب العمودي
          </h3>
          <div className="bg-white p-4 rounded-lg font-mono text-center text-lg">
            <div className="space-y-1">
              <div>    123</div>
              <div>  ×  45</div>
              <div>  ____</div>
              <div>    615  ← (123 × 5)</div>
              <div>   492   ← (123 × 4, منقول خانة)</div>
              <div>  ____</div>
              <div>   5535  ← المجموع النهائي</div>
            </div>
          </div>
        </div>
      </div>

      <div className="text-center mt-8">
        <button
          onClick={onBack}
          className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-8 py-4 rounded-xl text-lg font-semibold transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
        >
          🔙 العودة للقائمة الرئيسية
        </button>
      </div>
    </div>
  );
};

export default Instructions;