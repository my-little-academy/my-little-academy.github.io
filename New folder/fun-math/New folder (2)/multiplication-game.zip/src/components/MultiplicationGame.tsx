import React, { useState, useEffect } from 'react';
import { DifficultyLevel, GameStats } from '../App';

interface MultiplicationGameProps {
  difficulty: DifficultyLevel;
  onBackToMenu: () => void;
  gameStats: GameStats;
  updateGameStats: (stats: Partial<GameStats>) => void;
}

interface Problem {
  multiplicand: number;
  multiplier: number;
  steps: Step[];
  finalAnswer: number;
}

interface Step {
  digit: number;
  position: number;
  partialProduct: number;
  carry: number;
}

const MultiplicationGame: React.FC<MultiplicationGameProps> = ({
  difficulty,
  onBackToMenu,
  gameStats,
  updateGameStats
}) => {
  const [currentProblem, setCurrentProblem] = useState<Problem | null>(null);
  const [userAnswers, setUserAnswers] = useState<{ [key: string]: string }>({});
  const [currentStep, setCurrentStep] = useState(0);
  const [showHint, setShowHint] = useState(false);
  const [feedback, setFeedback] = useState<string>('');
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [problemsCompleted, setProblemsCompleted] = useState(0);
  const [showCelebration, setShowCelebration] = useState(false);

  useEffect(() => {
    generateNewProblem();
  }, [difficulty]);

  const generateRandomNumber = (minDigits: number, maxDigits: number): number => {
    const min = Math.pow(10, minDigits - 1);
    const max = Math.pow(10, maxDigits) - 1;
    return Math.floor(Math.random() * (max - min + 1)) + min;
  };

  const generateNewProblem = () => {
    const multiplicand = generateRandomNumber(difficulty.minDigits, difficulty.maxDigits);
    const multiplier = generateRandomNumber(1, difficulty.maxDigits);
    
    const steps: Step[] = [];
    const multiplierStr = multiplier.toString();
    
    for (let i = multiplierStr.length - 1; i >= 0; i--) {
      const digit = parseInt(multiplierStr[i]);
      const position = multiplierStr.length - 1 - i;
      const partialProduct = multiplicand * digit * Math.pow(10, position);
      steps.push({
        digit,
        position,
        partialProduct,
        carry: 0
      });
    }
    
    const finalAnswer = multiplicand * multiplier;
    
    setCurrentProblem({ multiplicand, multiplier, steps, finalAnswer });
    setUserAnswers({});
    setCurrentStep(0);
    setFeedback('');
    setIsCorrect(null);
    setShowHint(false);
  };

  const checkAnswer = (key: string, value: string) => {
    if (!currentProblem) return;
    
    const numericValue = parseInt(value);
    if (isNaN(numericValue)) return;
    
    let expectedValue = 0;
    
    if (key === 'final') {
      expectedValue = currentProblem.finalAnswer;
    } else if (key.startsWith('step_')) {
      const stepIndex = parseInt(key.split('_')[1]);
      expectedValue = currentProblem.steps[stepIndex].partialProduct;
    }
    
    const correct = numericValue === expectedValue;
    setIsCorrect(correct);
    
    if (correct) {
      setFeedback('🎉 ممتاز! إجابة صحيحة!');
      
      if (key === 'final') {
        // Problem completed successfully
        const newScore = gameStats.totalScore + (10 * difficulty.scoreMultiplier);
        const newStreak = gameStats.currentStreak + 1;
        const newHighestStreak = Math.max(gameStats.highestStreak, newStreak);
        
        updateGameStats({
          totalQuestions: gameStats.totalQuestions + 1,
          correctAnswers: gameStats.correctAnswers + 1,
          currentStreak: newStreak,
          highestStreak: newHighestStreak,
          totalScore: newScore
        });
        
        setProblemsCompleted(prev => prev + 1);
        setShowCelebration(true);
        
        setTimeout(() => {
          setShowCelebration(false);
          generateNewProblem();
        }, 2000);
      } else {
        // Move to next step or final answer
        setCurrentStep(prev => prev + 1);
      }
    } else {
      setFeedback('❌ حاول مرة أخرى! راجع حسابك.');
      updateGameStats({
        totalQuestions: gameStats.totalQuestions + 1,
        currentStreak: 0
      });
    }
  };

  const handleInputChange = (key: string, value: string) => {
    setUserAnswers(prev => ({ ...prev, [key]: value }));
    
    if (value.trim() !== '') {
      checkAnswer(key, value);
    }
  };

  const getHint = () => {
    if (!currentProblem) return '';
    
    if (currentStep < currentProblem.steps.length) {
      const step = currentProblem.steps[currentStep];
      return `اضرب ${currentProblem.multiplicand} × ${step.digit} = ${step.partialProduct}`;
    } else {
      return `اجمع جميع النتائج الجزئية للحصول على الإجابة النهائية`;
    }
  };

  if (!currentProblem) return <div>جاري التحميل...</div>;

  return (
    <div className="bg-white rounded-3xl shadow-2xl p-8 mx-auto max-w-4xl">
      {showCelebration && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-3xl p-8 text-center animate-bounce">
            <div className="text-6xl mb-4">🎉</div>
            <h3 className="text-2xl font-bold text-green-600 mb-2">رائع!</h3>
            <p className="text-lg text-gray-700">لقد حللت المسألة بنجاح!</p>
          </div>
        </div>
      )}
      
      <div className="flex justify-between items-center mb-6">
        <button
          onClick={onBackToMenu}
          className="bg-gray-500 hover:bg-gray-600 text-white px-6 py-3 rounded-xl font-semibold transition-colors duration-300"
        >
          🔙 العودة
        </button>
        
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-800">مستوى: {difficulty.name}</h2>
          <p className="text-gray-600">المسائل المحلولة: {problemsCompleted}</p>
        </div>
        
        <button
          onClick={() => setShowHint(!showHint)}
          className="bg-yellow-500 hover:bg-yellow-600 text-white px-6 py-3 rounded-xl font-semibold transition-colors duration-300"
        >
          💡 مساعدة
        </button>
      </div>

      {showHint && (
        <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-6 rounded-lg">
          <p className="text-yellow-800 font-medium">💡 {getHint()}</p>
        </div>
      )}

      <div className="bg-gray-50 rounded-2xl p-8 mb-6">
        <div className="text-center font-mono text-2xl space-y-2">
          <div className="flex justify-center items-center space-x-4">
            <span className="text-right" style={{ minWidth: '120px' }}>
              {currentProblem.multiplicand.toLocaleString()}
            </span>
          </div>
          <div className="flex justify-center items-center space-x-4">
            <span className="text-right" style={{ minWidth: '120px' }}>
              × {currentProblem.multiplier.toLocaleString()}
            </span>
          </div>
          <div className="border-t-2 border-gray-400 w-32 mx-auto"></div>
          
          {/* Partial products */}
          {currentProblem.steps.map((step, index) => (
            <div key={index} className="flex justify-center items-center space-x-4">
              <input
                type="number"
                value={userAnswers[`step_${index}`] || ''}
                onChange={(e) => handleInputChange(`step_${index}`, e.target.value)}
                className={`w-32 p-2 border-2 rounded-lg text-center font-mono text-xl ${
                  userAnswers[`step_${index}`] && 
                  parseInt(userAnswers[`step_${index}`]) === step.partialProduct
                    ? 'border-green-500 bg-green-50'
                    : 'border-gray-300'
                }`}
                placeholder={index <= currentStep ? "أدخل الناتج" : ""}
                disabled={index > currentStep}
              />
              {index <= currentStep && (
                <span className="text-sm text-gray-600">
                  ({currentProblem.multiplicand} × {step.digit})
                </span>
              )}
            </div>
          ))}
          
          <div className="border-t-2 border-gray-400 w-32 mx-auto"></div>
          
          {/* Final answer */}
          <div className="flex justify-center items-center space-x-4">
            <input
              type="number"
              value={userAnswers['final'] || ''}
              onChange={(e) => handleInputChange('final', e.target.value)}
              className={`w-32 p-2 border-2 rounded-lg text-center font-mono text-xl ${
                userAnswers['final'] && 
                parseInt(userAnswers['final']) === currentProblem.finalAnswer
                  ? 'border-green-500 bg-green-50'
                  : 'border-gray-300'
              }`}
              placeholder={currentStep >= currentProblem.steps.length ? "الناتج النهائي" : ""}
              disabled={currentStep < currentProblem.steps.length}
            />
            <span className="text-sm text-gray-600">المجموع النهائي</span>
          </div>
        </div>
      </div>

      {feedback && (
        <div className={`text-center p-4 rounded-lg mb-6 ${
          isCorrect ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
        }`}>
          <p className="text-lg font-semibold">{feedback}</p>
        </div>
      )}

      <div className="text-center space-x-4">
        <button
          onClick={generateNewProblem}
          className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 rounded-xl text-lg font-semibold transition-colors duration-300 shadow-lg"
        >
          🔄 مسألة جديدة
        </button>
        
        <button
          onClick={() => setUserAnswers({})}
          className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 rounded-xl text-lg font-semibold transition-colors duration-300 shadow-lg"
        >
          🗑️ مسح الإجابات
        </button>
      </div>

      <div className="mt-8 grid grid-cols-3 gap-4 text-center">
        <div className="bg-blue-100 p-4 rounded-xl">
          <div className="text-2xl font-bold text-blue-600">{gameStats.totalScore}</div>
          <div className="text-sm text-blue-800">النقاط</div>
        </div>
        <div className="bg-green-100 p-4 rounded-xl">
          <div className="text-2xl font-bold text-green-600">{gameStats.currentStreak}</div>
          <div className="text-sm text-green-800">نجاحات متتالية</div>
        </div>
        <div className="bg-purple-100 p-4 rounded-xl">
          <div className="text-2xl font-bold text-purple-600">{problemsCompleted}</div>
          <div className="text-sm text-purple-800">مسائل محلولة</div>
        </div>
      </div>
    </div>
  );
};

export default MultiplicationGame;