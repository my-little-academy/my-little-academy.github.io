import React from 'react';
import { GameStats } from '../App';

interface ScoreBoardProps {
  stats: GameStats;
}

const ScoreBoard: React.FC<ScoreBoardProps> = ({ stats }) => {
  const accuracy = stats.totalQuestions > 0 ? Math.round((stats.correctAnswers / stats.totalQuestions) * 100) : 0;

  return (
    <div className="bg-white rounded-3xl shadow-2xl p-6 mx-auto max-w-4xl">
      <div className="text-center mb-6">
        <img 
          src="/images/success-star.jpg" 
          alt="نجمة النجاح" 
          className="w-20 h-20 object-cover rounded-full mx-auto mb-4"
        />
        <h2 className="text-2xl font-bold text-gray-800">📊 لوحة النتائج</h2>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white p-4 rounded-2xl text-center">
          <div className="text-2xl font-bold">{stats.totalScore}</div>
          <div className="text-sm opacity-90">النقاط الإجمالية</div>
          <div className="text-2xl mt-1">🎯</div>
        </div>
        
        <div className="bg-gradient-to-br from-green-500 to-green-600 text-white p-4 rounded-2xl text-center">
          <div className="text-2xl font-bold">{stats.correctAnswers}</div>
          <div className="text-sm opacity-90">إجابات صحيحة</div>
          <div className="text-2xl mt-1">✅</div>
        </div>
        
        <div className="bg-gradient-to-br from-purple-500 to-purple-600 text-white p-4 rounded-2xl text-center">
          <div className="text-2xl font-bold">{accuracy}%</div>
          <div className="text-sm opacity-90">نسبة الدقة</div>
          <div className="text-2xl mt-1">📈</div>
        </div>
        
        <div className="bg-gradient-to-br from-orange-500 to-orange-600 text-white p-4 rounded-2xl text-center">
          <div className="text-2xl font-bold">{stats.currentStreak}</div>
          <div className="text-sm opacity-90">النجاحات المتتالية</div>
          <div className="text-2xl mt-1">🔥</div>
        </div>
        
        <div className="bg-gradient-to-br from-pink-500 to-pink-600 text-white p-4 rounded-2xl text-center">
          <div className="text-2xl font-bold">{stats.highestStreak}</div>
          <div className="text-sm opacity-90">أفضل سلسلة</div>
          <div className="text-2xl mt-1">👑</div>
        </div>
      </div>
      
      {stats.totalQuestions > 0 && (
        <div className="mt-6 text-center">
          <div className="bg-gray-100 rounded-full h-4 overflow-hidden">
            <div 
              className="bg-gradient-to-r from-green-400 to-green-600 h-full transition-all duration-500"
              style={{ width: `${accuracy}%` }}
            ></div>
          </div>
          <p className="mt-2 text-gray-600 font-medium">
            لقد أجبت على {stats.totalQuestions} سؤال بدقة {accuracy}% 🎉
          </p>
        </div>
      )}
    </div>
  );
};

export default ScoreBoard;